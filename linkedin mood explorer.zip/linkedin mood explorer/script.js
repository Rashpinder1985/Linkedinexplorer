document.addEventListener('DOMContentLoaded', () => {
    const moodButtons = document.querySelectorAll('.mood-btn');
    const reflectionText = document.getElementById('reflection');
    const historyList = document.getElementById('history');
    const moodChartCanvas = document.getElementById('moodChart').getContext('2d');
    let moodHistory = [];
    let moodCounts = {
        Red: 0,
        Blue: 0,
        Yellow: 0,
        Green: 0,
        Purple: 0,
        Orange: 0,
        Black: 0
    };

    let moodChart;

    function initializeChart() {
        moodChart = new Chart(moodChartCanvas, {
            type: 'bar',
            data: {
                labels: Object.keys(moodCounts),
                datasets: [{
                    label: 'Mood Count',
                    data: Object.values(moodCounts),
                    backgroundColor: [
                        '#e74c3c', '#3498db', '#f1c40f',
                        '#2ecc71', '#9b59b6', '#e67e22', '#34495e'
                    ],
                    borderColor: '#ccc',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function updateChart() {
        moodChart.data.datasets[0].data = Object.values(moodCounts);
        moodChart.update();
    }

    moodButtons.forEach(button => {
        button.addEventListener('click', () => {
            const mood = button.dataset.mood;
            const emoji = button.dataset.emoji;
            reflectMood(mood, emoji);
            addMoodToHistory(mood, emoji);
            updateMoodAnalytics();
        });
    });

    function reflectMood(mood, emoji) {
        let reflection;
        switch (mood) {
            case 'Red':
                reflection = `You feel motivated and driven based on the content you saw. ${emoji}`;
                break;
            case 'Blue':
                reflection = `The content made you feel stressed or overwhelmed. Consider taking a break. ${emoji}`;
                break;
            case 'Yellow':
                reflection = `You feel happy and satisfied with the content you saw! ${emoji}`;
                break;
            case 'Green':
                reflection = `The content has left you feeling calm and balanced. ${emoji}`;
                break;
            case 'Purple':
                reflection = `You're curious and intrigued by what you saw. ${emoji}`;
                break;
            case 'Orange':
                reflection = `You feel social and connected after browsing. ${emoji}`;
                break;
            case 'Black':
                reflection = `The content made you feel frustrated or disappointed. ${emoji}`;
                break;
            default:
                reflection = "Select a mood to see your reflection.";
        }
        reflectionText.textContent = reflection;
    }

    function addMoodToHistory(mood, emoji) {
        moodHistory.push({ mood, emoji });
        moodCounts[mood]++;
        updateMoodHistory();
    }

    function updateMoodHistory() {
        historyList.innerHTML = "";
        moodHistory.forEach((entry, index) => {
            const li = document.createElement('li');
            li.textContent = `${index + 1}. Mood: ${entry.mood} ${entry.emoji}`;
            historyList.appendChild(li);
        });
    }

    function updateMoodAnalytics() {
        updateChart();
    }

    // Initialize the chart on page load
    initializeChart();
});
